package com.cedup.calculadoradesomar;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class Calculadora extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_calculadora);
    }

    public void somar(View view) {
        EditText txtNum1 = findViewById(R.id.txtNum1);
        EditText txtNum2 = findViewById(R.id.txtNum2);
        Button btnOk = findViewById(R.id.btnOk);
        double n1 = Double.parseDouble(txtNum1.getText().toString());
        double n2 = Double.parseDouble(txtNum2.getText().toString());
        TextView lblResultado = findViewById(R.id.lblResultado);
        lblResultado.setText("Resultado ; " + (n1 + n2));
        lblResultado.setVisibility(View.VISIBLE);
    }
}