package com.cedup.pacotedeapps;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class Lista extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.act_lista);
    }

    public void fechar(View v) {
        finish();
    }
}