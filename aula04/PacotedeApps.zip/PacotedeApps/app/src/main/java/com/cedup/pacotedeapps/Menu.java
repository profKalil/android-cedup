package com.cedup.pacotedeapps;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class Menu extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.act_menu);
    }

    public void calculadora(View v) {
        Intent i = new Intent (this, Calculadora.class);
        startActivity(i);
    }

    public void conversor(View v) {
        Intent i = new Intent(this, Conversor.class);
        startActivity(i);
    }

    public void lista(View v) {
        Intent i = new Intent(this, Lista.class);
        startActivity(i);
    }
}