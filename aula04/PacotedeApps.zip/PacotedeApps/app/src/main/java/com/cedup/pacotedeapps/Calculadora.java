package com.cedup.pacotedeapps;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;

public class Calculadora extends Activity {

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.act_calculadora);
    }

    public void fechar(View v) {
        finish();
    }
}