package com.cedup.gerenciadordetarefas;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class DataBaseHelper {
    private static final String TAG = "DataBaseHelper";
    private static final String DB_NAME = "db_tarefas.db";
    private SQLiteDatabase banco;
    private final Context context;
    private final SQLiteOpenHelper dbHelper;

    public DataBaseHelper(Context c) {
        this.context = c;
        this.dbHelper = new DBTarefa(c);
    }

    public void conectarDB() {
        banco = dbHelper.getReadableDatabase();
    }

    public void fecharConexaoDB() {
        if (banco != null) {
            banco.close();
        }
    }

    public void copiarArquivosDB() {
        try {
            InputStream is = context.getAssets().open("db_tarefas.db");
            File dir = context.getDatabasePath("databases").getParentFile();
            if (dir != null)
                if (!dir.exists())
                    dir.mkdirs();
            File dbFile = new File(dir, "db_tarefas.db");
            if (!dbFile.exists()) {
                FileOutputStream fos = new FileOutputStream(dbFile);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    fos.write(buffer, 0, length);
                }
                fos.flush();
                fos.close();
                is.close();
            }

            SQLiteDatabase db = SQLiteDatabase.openDatabase(dbFile.getAbsolutePath(), null, SQLiteDatabase.OPEN_READWRITE);
            ContentValues values = new ContentValues();
            values.put("tarefa", "Tarefa de Exemplo");
            long newRowId = db.insert("tarefas", null, values);
            db.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public boolean checkDB() {
        SQLiteDatabase db = null;
        try {
            String path = context.getDatabasePath(DB_NAME).getPath();
            db = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READONLY);
        } catch (SQLiteException e) {
            Log.e(TAG, "Database does not exist or could not be opened.", e);
        }
        if (db != null) {
            db.close();
        }
        return db != null;
    }


    public ModelTarefa[] getTabela() {
        conectarDB();
        Cursor c = banco.rawQuery("SELECT * FROM tb_tarefas", null);
        ModelTarefa[] out = null;

        if (c != null && c.moveToFirst()) {
            out = new ModelTarefa[c.getCount()];
            int i = 0;
            do {
                out[i] = new ModelTarefa(c.getInt(0), c.getString(1));
                Log.d("DB_DEBUG", "Tarefa encontrada: " + out[i].getTarefa());
                i++;
            } while (c.moveToNext());
        } else {
            Log.d("DB_DEBUG", "Nenhuma tarefa encontrada no banco de dados");
        }

        if (c != null) {
            c.close();
        }
        fecharConexaoDB();

        return out != null ? out : new ModelTarefa[0];
    }
}
