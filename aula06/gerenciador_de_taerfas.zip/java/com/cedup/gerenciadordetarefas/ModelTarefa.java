package com.cedup.gerenciadordetarefas;

public class ModelTarefa {
    private int id;
    private String tarefa;

    public ModelTarefa(int id, String tarefa) {
        this.id = id;
        this.tarefa = tarefa;
    }

    /** @noinspection unused*/
    public int getId() {
        return id;
    }

    /** @noinspection unused*/
    public void setId(int id) {
        this.id = id;
    }

    public String getTarefa() {
        return tarefa;
    }

    /** @noinspection unused*/
    public void setTarefa(String tarefa) {
        this.tarefa = tarefa;
    }
}
