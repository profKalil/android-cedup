package com.cedup.gerenciadordetarefas;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainTarefa extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefas);

        TextView txtTarefa = findViewById(R.id.txtTarefa);
        DataBaseHelper data = new DataBaseHelper(getApplicationContext());

        if (!data.checkDB()) {
            data.copiarArquivosDB();
        }

        ModelTarefa[] tarefaArray = data.getTabela();
        if (tarefaArray != null && tarefaArray.length > 0) {
            txtTarefa.setText(tarefaArray[0].getTarefa());
        } else {
            txtTarefa.setText("Nenhuma tarefa encontrada!");
        }
    }
}